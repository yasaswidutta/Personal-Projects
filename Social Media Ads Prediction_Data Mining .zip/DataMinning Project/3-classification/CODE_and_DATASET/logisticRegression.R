#logistic regression

#data pre-processing
data<-read.csv(file.choose())
data<-data[,3:5]
head(data)
#splitting into test and train data-set
# install.packages("caTools")
library(caTools)
set.seed(123)
split <- sample.split(data$Purchased, SplitRatio = 0.75)
split
train.set<-subset(data, split==T)
test.set<-subset(data, split==F)

#feature scalling
train.set[,1:2]<-scale(train.set[,1:2])
test.set[,1:2]<-scale(test.set[,1:2])

#fitting logistic regression to training dataset
classifier<-glm(formula = Purchased~.,
                family = binomial,
                data = train.set)
#predict the test set
prob.pred<-predict(classifier,
                   type = 'response',
                   newdata = test.set[-3])
prob.pred
y.pred<-ifelse(prob.pred>0.5, 1, 0)
y.pred

#making the confusion matrix
cm<-table(test.set[,3], y.pred)
cm

#visualizing the train set results
library(ElemStatLearn)
set = train.set
X1 = seq(min(set[, 1]) - 1, max(set[, 1]) + 1, by = 0.01)
X2 = seq(min(set[, 2]) - 1, max(set[, 2]) + 1, by = 0.01)
grid_set = expand.grid(X1, X2)
colnames(grid_set) = c('Age', 'EstimatedSalary')
prob_set = predict(classifier, type = 'response', newdata = grid_set)
y_grid = ifelse(prob_set > 0.5, 1, 0)
plot(set[, -3],
     main = 'Logistic Regression (Training set)',
     xlab = 'Age', ylab = 'Estimated Salary',
     xlim = range(X1), ylim = range(X2))
contour(X1, X2, matrix(as.numeric(y_grid), length(X1), length(X2)), add = TRUE)
points(grid_set, pch = '.', col = ifelse(y_grid == 1, 'springgreen3', 'tomato'))
points(set, pch = 21, bg = ifelse(set[, 3] == 1, 'green4', 'red3'))

#visualizing the test set results
library(ElemStatLearn)
set = test.set
X1 = seq(min(set[, 1]) - 1, max(set[, 1]) + 1, by = 0.01)
X2 = seq(min(set[, 2]) - 1, max(set[, 2]) + 1, by = 0.01)
grid_set = expand.grid(X1, X2)
colnames(grid_set) = c('Age', 'EstimatedSalary')
prob_set = predict(classifier, type = 'response', newdata = grid_set)
y_grid = ifelse(prob_set > 0.5, 1, 0)
plot(set[, -3],
     main = 'Logistic Regression (Test set)',
     xlab = 'Age', ylab = 'Estimated Salary',
     xlim = range(X1), ylim = range(X2))
contour(X1, X2, matrix(as.numeric(y_grid), length(X1), length(X2)), add = TRUE)
points(grid_set, pch = '.', col = ifelse(y_grid == 1, 'springgreen3', 'tomato'))
points(set, pch = 21, bg = ifelse(set[, 3] == 1, 'green4', 'red3'))