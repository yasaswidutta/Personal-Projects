---
  title: "PROJECT CODE"
author: "18mis1033_swathi J & 18mis1105"
output:
html_document: default

---
```{r, echo=TRUE}
# Libraries
library(RedditExtractoR)
library(radarchart)
library(tm)
library(syuzhet)


# Getting Reddit Data
links <- reddit_urls(search_terms = "clov", page_threshold = 20)
head(links,10)
links1 <- reddit_urls(search_terms = "amc", page_threshold = 20)
head(links1,10)
links2 <- reddit_urls(search_terms = "GME", page_threshold = 20)
head(links2,10)

# User network plot
content <- reddit_content(links$URL[1])
head(content,10)
user <- user_network(content, include_author = T, agg = TRUE)
user$plot
graph1 <- construct_graph(content, plot = TRUE)

content1 <- reddit_content(links1$URL[1])
head(content1,10)
user1 <- user_network(content, include_author = T, agg = TRUE)
user1$plot
graph2 <- construct_graph(content, plot = TRUE)

content2 <- reddit_content(links2$URL[1])
head(content2,10)
user2 <- user_network(content, include_author = T, agg = TRUE)
user2$plot
graph3 <- construct_graph(content, plot = TRUE)

# Sentiment analysis 
com1<- iconv(content$comment, to = 'utf-8')
clov<- get_nrc_sentiment(com1)
print(clov)
com2<- iconv(content1$comment, to = 'utf-8')
amc<- get_nrc_sentiment(com2)
print(amc)
com3<- iconv(content2$comment, to = 'utf-8')
gme<- get_nrc_sentiment(com3)
print(gme)
# Radar chart
x1 <- data.frame(Clover=100*colSums(clov)/sum(clov)) 
x2 <- data.frame(AMC=100*colSums(amc)/sum(amc)) 
x3 <- data.frame(GameStop=100*colSums(gme)/sum(gme)) 
z <- cbind(x1, x2, x3)
print(x1)
print(x2)
print(x3)
print(z)
labs <- rownames(z)
chartJSRadar(z, 
             labs = labs,
             labelSize = 30,
             main = 'AMC Vs CLOV Vs GME: Sentiment Analysis of Reddit Comments')

```

